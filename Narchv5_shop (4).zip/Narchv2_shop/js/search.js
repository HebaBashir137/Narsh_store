document.addEventListener('DOMContentLoaded', () => {
  const search = () => {
    const term = document.getElementById('search-input').value.trim().toLowerCase();
    if (!term) return alert('Please enter a search term');
    
    const results = Array.from(document.querySelectorAll('h2'))
      .filter(h2 => h2.textContent.toLowerCase().includes(term))
      .map(h2 => h2.textContent);
    
    alert(results.length ? `Found:\n${results.join('\n')}` : 'No results found');
  };

  document.getElementById('search-bt').addEventListener('click', search);
  document.getElementById('search-input').addEventListener('keypress', e => e.key === 'Enter' && search());
});